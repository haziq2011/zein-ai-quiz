"use client";

import { useMemo, useState } from "react";

type Question = {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
};

type Quiz = {
  title: string;
  questions: Question[];
};

const subjects = [
  "Bahasa Melayu", "Bahasa Inggeris", "Matematik", "Sains",
  "Sejarah", "Geografi", "Pendidikan Islam", "Reka Bentuk dan Teknologi"
];

export default function Home() {
  const [form, setForm] = useState({
    level: "Tingkatan 3",
    subject: "Geografi",
    topic: "",
    count: "10",
    difficulty: "Sederhana"
  });
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const question = quiz?.questions[current];
  const progress = useMemo(
    () => quiz ? Math.round(((current + 1) / quiz.questions.length) * 100) : 0,
    [quiz, current]
  );

  async function generateQuiz() {
    if (!form.topic.trim()) {
      setError("Masukkan bab atau topik dahulu.");
      return;
    }
    setLoading(true);
    setError("");
    setQuiz(null);
    setFinished(false);
    setCurrent(0);
    setSelected(null);
    setScore(0);

    try {
      const res = await fetch("/api/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menjana kuiz.");
      setQuiz(data.quiz);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ralat tidak diketahui.");
    } finally {
      setLoading(false);
    }
  }

  function choose(index: number) {
    if (selected !== null || !question) return;
    setSelected(index);
    if (index === question.answer) setScore(s => s + 1);
  }

  function next() {
    if (!quiz) return;
    if (current + 1 >= quiz.questions.length) {
      setFinished(true);
    } else {
      setCurrent(c => c + 1);
      setSelected(null);
    }
  }

  function reset() {
    setQuiz(null);
    setFinished(false);
    setCurrent(0);
    setSelected(null);
    setScore(0);
    setError("");
  }

  return (
    <main className="page">
      <section className="shell">
        <header className="hero">
          <div className="logo">Z</div>
          <div>
            <p className="eyebrow">ZEIN TECHNOLOGY</p>
            <h1>ZEIN AI QUIZ</h1>
            <p className="sub">Jana kuiz pembelajaran secara automatik dengan AI.</p>
          </div>
        </header>

        {!quiz && (
          <section className="card formCard">
            <h2>✨ Bina Kuiz</h2>
            <p className="muted">Masukkan maklumat pembelajaran anda.</p>

            <label>Tingkatan / Tahun
              <select value={form.level} onChange={e => setForm({...form, level: e.target.value})}>
                {["Tahun 4","Tahun 5","Tahun 6","Tingkatan 1","Tingkatan 2","Tingkatan 3","Tingkatan 4","Tingkatan 5"].map(x => <option key={x}>{x}</option>)}
              </select>
            </label>

            <label>Subjek
              <select value={form.subject} onChange={e => setForm({...form, subject: e.target.value})}>
                {subjects.map(x => <option key={x}>{x}</option>)}
              </select>
            </label>

            <label>Bab / Topik
              <input value={form.topic} onChange={e => setForm({...form, topic: e.target.value})} placeholder="Contoh: Cuaca dan Iklim" />
            </label>

            <div className="grid2">
              <label>Bilangan soalan
                <select value={form.count} onChange={e => setForm({...form, count: e.target.value})}>
                  {["5","10","15","20"].map(x => <option key={x}>{x}</option>)}
                </select>
              </label>
              <label>Tahap
                <select value={form.difficulty} onChange={e => setForm({...form, difficulty: e.target.value})}>
                  {["Mudah","Sederhana","Sukar"].map(x => <option key={x}>{x}</option>)}
                </select>
              </label>
            </div>

            {error && <div className="error">{error}</div>}
            <button className="primary" onClick={generateQuiz} disabled={loading}>
              {loading ? "⏳ AI sedang menjana..." : "✨ JANA KUIZ AI"}
            </button>
          </section>
        )}

        {quiz && !finished && question && (
          <section className="card quizCard">
            <div className="quizTop">
              <span>Soalan {current + 1}/{quiz.questions.length}</span>
              <span>{progress}%</span>
            </div>
            <div className="progress"><span style={{width: `${progress}%`}} /></div>
            <h2>{question.question}</h2>

            <div className="options">
              {question.options.map((option, i) => {
                const state = selected === null ? "" : i === question.answer ? "correct" : i === selected ? "wrong" : "";
                return <button key={i} className={`option ${state}`} onClick={() => choose(i)}>
                  <b>{String.fromCharCode(65 + i)}</b>{option}
                </button>;
              })}
            </div>

            {selected !== null && (
              <div className={`explanation ${selected === question.answer ? "good" : "bad"}`}>
                <strong>{selected === question.answer ? "✅ Betul!" : "❌ Kurang tepat"}</strong>
                <p>{question.explanation}</p>
              </div>
            )}

            <button className="primary" onClick={next} disabled={selected === null}>
              {current + 1 === quiz.questions.length ? "🏁 Lihat Keputusan" : "Seterusnya →"}
            </button>
          </section>
        )}

        {finished && quiz && (
          <section className="card result">
            <div className="trophy">🏆</div>
            <p className="eyebrow">KEPUTUSAN</p>
            <h2>{score} / {quiz.questions.length}</h2>
            <p>{score === quiz.questions.length ? "Hebat! Semua jawapan betul." : "Bagus! Teruskan berlatih untuk tingkatkan markah."}</p>
            <button className="primary" onClick={reset}>🔄 Bina Kuiz Baharu</button>
          </section>
        )}

        <footer>ZEIN AI QUIZ • Dibina untuk pembelajaran</footer>
      </section>
    </main>
  );
}