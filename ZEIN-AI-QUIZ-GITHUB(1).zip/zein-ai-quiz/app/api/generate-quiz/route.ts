import { NextResponse } from "next/server";

export const runtime = "nodejs";

type Body = {
  level?: string;
  subject?: string;
  topic?: string;
  count?: string;
  difficulty?: string;
};

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Body;
    const { level, subject, topic, count, difficulty } = body;

    if (!level || !subject || !topic || !count || !difficulty) {
      return NextResponse.json({ error: "Maklumat kuiz tidak lengkap." }, { status: 400 });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

    if (!apiKey) {
      return NextResponse.json({
        error: "OPENAI_API_KEY belum ditetapkan. Tambah API key di Vercel → Settings → Environment Variables."
      }, { status: 500 });
    }

    const prompt = `Anda ialah pembina kuiz pendidikan Bahasa Melayu untuk pelajar Malaysia.
Hasilkan ${count} soalan objektif bagi:
Tingkatan/Tahun: ${level}
Subjek: ${subject}
Bab/Topik: ${topic}
Tahap: ${difficulty}

Pastikan soalan sesuai dengan tahap pelajar, jelas, tidak mengelirukan dan tidak memerlukan maklumat di luar topik.
Setiap soalan mesti mempunyai tepat 4 pilihan jawapan.
Jawapan ialah nombor indeks 0 hingga 3.
Berikan penerangan ringkas dalam Bahasa Melayu.

BALAS HANYA JSON sah mengikut struktur:
{
  "title": "tajuk kuiz",
  "questions": [
    {
      "question": "soalan",
      "options": ["A","B","C","D"],
      "answer": 0,
      "explanation": "penerangan"
    }
  ]
}`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "Anda menjana data kuiz JSON yang sah sahaja." },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      const detail = await response.text();
      console.error(detail);
      return NextResponse.json({ error: "AI gagal menjana kuiz. Semak API key/model anda." }, { status: 502 });
    }

    const data = await response.json();
    const raw = data.choices?.[0]?.message?.content;
    if (!raw) throw new Error("Respons AI kosong.");

    const quiz = JSON.parse(raw);
    if (!quiz.title || !Array.isArray(quiz.questions) || quiz.questions.length === 0) {
      throw new Error("Format kuiz AI tidak sah.");
    }

    return NextResponse.json({ quiz });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Ralat semasa menjana kuiz." }, { status: 500 });
  }
}